import React from 'react';
import './App.css';
import Registrasi from './page/Registrasi'

function App() {
  return (
    <div>
      <h1>Belajar React Di Hari Senin. Test Github</h1>
      <Registrasi />
    </div>
  );
}

export default App;
